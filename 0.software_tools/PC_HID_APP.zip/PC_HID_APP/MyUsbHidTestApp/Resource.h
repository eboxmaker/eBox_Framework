//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by MyUsbHidTestApp.rc
//
#define IDM_ABOUTBOX                    0x0010
#define IDD_ABOUTBOX                    100
#define IDS_ABOUTBOX                    101
#define IDD_MYUSBHIDTESTAPP_DIALOG      102
#define IDR_MAINFRAME                   128
#define IDI_LED_OFF                     130
#define IDI_LED_ON                      131
#define IDI_ICON1                       132
#define IDI_ICON2                       133
#define IDI_ICON3                       134
#define IDI_ICON4                       135
#define IDI_ICON5                       136
#define IDI_ICON6                       137
#define IDI_ICON7                       138
#define IDC_OPEN_DEVICE                 1000
#define IDC_VID_EDIT                    1001
#define IDC_PID_EDIT                    1002
#define IDC_LED1                        1003
#define IDC_CLOSE_DEVICE                1004
#define IDC_LED2                        1005
#define IDC_LED3                        1006
#define IDC_LED4                        1007
#define IDC_LED5                        1008
#define IDC_LED6                        1009
#define IDC_LED7                        1010
#define IDC_LED8                        1011
#define IDC_KEY1                        1012
#define IDC_KEY2                        1013
#define IDC_KEY3                        1014
#define IDC_KEY4                        1015
#define IDC_KEY5                        1016
#define IDC_KEY6                        1017
#define IDC_KEY7                        1018
#define IDC_KEY8                        1019
#define IDC_CLEAR_COUNTER               1020
#define IDC_PVN_EDIT                    1021
#define IDC_ABOUT                       1022
#define IDC_QUIT                        1023
#define IDC_INF_OUT                     1030
#define IDC_CLEAR_INF                   1034
#define IDC_COUNTER                     1037
#define IDC_DS                          1039

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        140
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1024
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
